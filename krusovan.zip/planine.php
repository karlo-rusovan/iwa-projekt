<?php 
	//dodati da se vidi gumb unblokiraj i da ga moš unblokirati
	
	
	//početak sesije
	session_start();
	
	// početak rada s bazom
	include_once ('baza.php');
	$veza = baza_spajanje();	
	
	//provjera ako je korisnik administrator, ako nije nije mu dopušten pristup stranici
	if (!isset($_SESSION['tip_korisnika']) || $_SESSION["tip_korisnika"] != 0) {
		 header('Location: prijava.php');
	}
		
	$upit_planina = "SELECT * FROM planina ";
	$rezultat_planina = izvrsiUpit($veza, $upit_planina);	
	
?>

<!DOCTYPE html>
<html>

	<head>
	
		<title>Planine</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
		
	</head>
	
	<body>	
		
		<header> 		
			<h1>Popis planina</h1>				
		</header>
	
		<!-- navigacija -->
		<?php
			include_once ('navigacija.php');					
		?>	
		
		<a href="planine.php?"><input type="button" name="unos" class="gumb" value="Popis planina" /></a>				
		<a href="unos_planine.php"><input type="button" name="unos" class="gumb" value="Unos nove planine" /></a>	
		
		
		<?php
			if ($rezultat_planina) {
				echo "<table id='admin_planine_tablica'>
						<thead>
							<tr>
								<th class='admin_planine_data'></th>
								<th class='admin_planine_data'>Naziv</th>
								<th class='admin_planine_data'>Opis</th>
								<th class='admin_planine_data'>Lokacija</th>
								<th class='admin_planine_data'>Koordinate</th>								
							</tr>
						</thead><tbody>";				
				while ($red_planina = mysqli_fetch_array($rezultat_planina)) {
					
					$naziv = $red_planina['naziv'];
					$planina = $red_planina['planina_id'];
					$opis = $red_planina['opis'];
					$lokacija = $red_planina['lokacija'];
					$geografska_sirina = $red_planina['geografska_sirina'];
					$geografska_duzina = $red_planina['geografska_duzina'];
					
					
					$upit_slika = " SELECT slika.url FROM slika
					INNER JOIN planina ON planina.planina_id = slika.planina_id
					WHERE slika.planina_id = '{$planina}'";		
					$rezultat_slika = izvrsiUpit($veza,$upit_slika);					
					$red_slika = mysqli_fetch_array($rezultat_slika);
					
					if (!empty($red_slika)) {					
						$url = $red_slika['url'];					
					} else {
						$url = "https://live.staticflickr.com/4511/36844950564_70b897f770_z.jpg";
					}				
					
					
					echo "					
							<tr>										
								<td class='moderator_slika'><a href='planina.php?planina_id={$planina}'><img class='admin_planine_slika' src='{$url}'/></a></td>
								<td class='admin_planine_data'><a href='planina.php?planina_id={$planina}'>{$naziv}</a></td>
								<td style='text-align:left' class='admin_planine_data'>{$opis}</td>	
								<td style='text-align:left' class='admin_planine_data'>{$lokacija}</td>	
								<td class='admin_planine_data'><a href='https://www.google.com/maps/?q={$geografska_sirina},{$geografska_duzina}' target='_blank'>{$geografska_sirina} {$geografska_duzina}</a></td>
								<td class='admin_planine_data'><a href='azuriranje_planine.php?planina_id={$planina}&planina_url={$url}'><input type='button' class='gumb' value='Ažuriraj'/></a></td>
							</tr>					
					";			
				}
				echo "</tbody></table>";
			}
		?>
	
		<!-- footer -->
		<?php
			include_once ('footer.php');			
			
			// zatvarenje konekcije
			zatvoriVezuNaBazu($veza);

		?>
		
	</body>
	
</html>

