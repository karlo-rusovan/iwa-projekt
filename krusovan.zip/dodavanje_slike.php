
<?php 
	
	session_start();
	
	if (!isset($_SESSION["korisnik_id"])) {
	   header('Location: prijava.php');
	}	
	
	include_once ('baza.php');
	$veza = baza_spajanje();	

	if (isset($_GET['unesi'])) {	
		
		$planina = $_GET['planina'];
		$naziv = $_GET['naziv'];
		$opis = $_GET['opis'];
		$status = $_GET['status'];
		$datum = date("Y-m-d H:i:s", strtotime($_GET['datum']));
		$url = $_GET['url'];
		$korisnik_id = $_SESSION["korisnik_id"];
				
		$upit_blokiran = "SELECT blokiran FROM korisnik
		WHERE korisnik_id = '{$korisnik_id}'";		
		$rezultat_blokiran = izvrsiUpit($veza,$upit_blokiran);
		$red_blokiran = mysqli_fetch_array($rezultat_blokiran);
		
		if ($red_blokiran['blokiran'] == 1) {	
		
			$blokiran = " ";
			
		} else if(empty($planina) || empty($naziv) || empty($opis) || empty($datum) || empty($url)) {
			$podaci_nisu_uneseni = " ";
		} else {
			
			$upit_dodaj = "INSERT INTO `slika`(`planina_id`, `korisnik_id`, `naziv`, `url`,
			`opis`, `datum_vrijeme_slikanja`, `status`) VALUES ('{$planina}','{$korisnik_id}','{$naziv}','{$url}','{$opis}','{$datum}','{$status}')";				
			izvrsiUpit($veza,$upit_dodaj);	
			
			$id_dodane_slike = mysqli_insert_id($veza); 	
			
			header("Location:podaci_o_slici.php?id_slike={$id_dodane_slike}");	
			
		}			
	}


?>

<!DOCTYPE html>
<html>

	<head>
	
		<title>Dodavanje slike</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
		
	</head>
	
	<body>	
		
		<header> 		
			<h1>Dodavanje slike</h1>				
		</header>	
		
		<?php
			include_once ('navigacija.php');	
		?>	
		
		<table id="tablica_azuriranje">	
			
			<img style="float:left" src='https://media-cdn.tripadvisor.com/media/photo-s/12/ba/02/6b/dinara.jpg' width='450px' height='288px' />			
			
			<tr>
				<form name="filtriranje_slika" action="<?php echo $_SERVER['PHP_SELF']?>" method='GET'>
			
				<td><label for="planina">Planina:</label></td>
				<td><select name="planina" class="tekst_unos" id="dropdown_planine">
					<?php
						$upit_planine = "SELECT * FROM planina";
						$rezultat_planine = izvrsiUpit($veza,$upit_planine);
						
						if ($rezultat_planine) {
							
							while($red = mysqli_fetch_array($rezultat_planine)) {
								
								$planina_id = $red['planina_id'];
								$planina_naziv = $red['naziv'];
								
								echo "<option value='{$planina_id}'>{$planina_naziv}</option>";								
							}				
						}
						
					?>
					</select></td>
			</tr>
			<tr>
				<td><label for="naziv">Naziv:</label></td>
				<td><input type="text" name="naziv" class="tekst_unos" size="23"  /></td>
			</tr>
			<tr>
				<td><label for="naziv">Opis:</label></td>
				<td><textarea name="opis" cols="25" class="tekst_unos" placeholder="kratak opis slike"></textarea></td>
			</tr>
			<tr>
				<td><label for="datum">Datum slike:</label></td>
				<td><input type="text" name="datum" class="tekst_unos" size="23" placeholder="d.m.Y H:i:s" /></td>
			</tr>
			<tr>
				<td><label for="url">URL slike:</label></td>
				<td><input type="text" name="url" class="tekst_unos" size="23" placeholder="http://www.stranica.com/slika.jpg" /></td>
			</tr>
			<tr>				
				<td><label for="status">Javna:</label></td>
				<td><input type="radio" name="status" value="1"	checked /></td>
			</tr>
			<tr>
				<td><label for="status">Privatna:</label></td>
				<td><input type="radio" name="status" value="0" disabled /></td>
			</tr>
			<tr>			
				<td><input type="submit" name="unesi" value="Unesi" class="gumb" /></td>				
			</tr>					
				</form>			
		</table>			
		
		<?php
		     if(isset($blokiran)){
					Echo "<div class='alert' style='position:relative; left:50px'>Korisnik je blokiran, slika se ne može dodati</div>";
			} else if (isset($podaci_nisu_uneseni)) {
					Echo "<div class='alert' style='position:relative; left:50px'>Potrebno je popuniti sve podatke</div>";
			}
		?>					
	
		<?php
			include_once ('footer.php');			
			zatvoriVezuNaBazu($veza);
		?>
		
	</body>
	
</html>
