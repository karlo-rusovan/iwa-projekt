<!DOCTYPE html>
<?php
session_start();
?>	

<html>
	
	<head>
		
		<title>O autoru</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
	
	</head>
	
	<body>		
		
		<header> 		
			<h1>O autoru</h1>				
		</header>	
	
		<?php
			include_once ('navigacija.php');
		?>	
		
		<table>		
			<tr>			
				<td>
					<img src="slike/autor.jpg" width="330px" height="300px" />
				</td>
				
				<td>
					<ul>
						<li>Ime: Karlo</li>		
						<li>Prezime: Rusovan</li>	
						<li>Broj indeksa: 0016139899</li>	
						<li>Mail: krusovan@foi.hr</li>	
						<li>Centar: Varaždin</li>	
						<li>Godina: 2020/2021.</li>	
					</ul>	
				</td>
			</tr>				
		</table>	
	
		<?php
			include_once ('footer.php');
		?>
	
	</body>

</html>