<!DOCTYPE html>


<?php		
	session_start();	
	
	include_once ('baza.php');
	$veza = baza_spajanje();	

	if (isset($_GET['korisnik_id'])) {
		$korisnik_id = $_GET['korisnik_id'];
	
		$upit = "SELECT * FROM slika 			
			WHERE slika.status = 1 AND korisnik_id = {$korisnik_id}
			ORDER BY datum_vrijeme_slikanja DESC";		
			$rezultat = izvrsiUpit($veza,$upit);	
	} else if (isset($_GET['naziv_planine'])) {
		
		$naziv = $_GET['naziv_planine'];	
		
		if (isset($_GET['vrijeme_od']) && isset($_GET['vrijeme_do'])) {
				
			$vrijeme_od = date("Y-m-d H:i:s", strtotime($_GET['vrijeme_od']));
			$vrijeme_do = date("Y-m-d H:i:s", strtotime($_GET['vrijeme_do']));	
			
			$upit = "SELECT * FROM slika 
			INNER JOIN planina 
			ON planina.planina_id = slika.planina_id
			WHERE slika.status = 1 AND planina.naziv LIKE '%{$naziv}%' AND slika.datum_vrijeme_slikanja BETWEEN '{$vrijeme_od}' AND '{$vrijeme_do}'
			ORDER BY datum_vrijeme_slikanja DESC";		
			$rezultat = izvrsiUpit($veza,$upit);
			
		} else {			
			$upit = "SELECT * FROM slika 
			INNER JOIN planina 
			ON planina.planina_id = slika.planina_id
			WHERE slika.status = 1 AND planina.naziv LIKE '%{$naziv}%'
			ORDER BY datum_vrijeme_slikanja DESC";		
			$rezultat = izvrsiUpit($veza,$upit);				
		}
			
	} else {
			$upit = "SELECT * FROM slika 
			INNER JOIN planina 
			ON planina.planina_id = slika.planina_id
			WHERE slika.status = 1 
			ORDER BY datum_vrijeme_slikanja DESC";		
			$rezultat = izvrsiUpit($veza,$upit);	
			}

	zatvoriVezuNaBazu($veza);
	
?>


<html>
	
	<head>
		
		<title>Galerija slika</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
		<meta content="width=device-width, initial-scale=1" name="viewport" />
	
	</head>
	
	<body>		
		
		<header> 		
			<h1>Galerija javnih slika</h1>				
		</header>	
		
		<?php
			include_once ('navigacija.php');
		?>			
		
		<table>
		
			<form name="filtriranje_slika" action="<?php echo $_SERVER['PHP_SELF']?>" id="filtriranje_slika" method="GET">
							
				<tbody>
					<tr>
						<td>Naziv planine:</td>
						<td><input class="tekst_unos" type="text" name="naziv_planine" size="12" /></td>	
						<td><input class="gumb" type="submit" name="filtriraj" value="Filtriraj"/></td>							
					</tr>
					<tr>
						<td>Vrijeme od:</td>
						<td><input class="tekst_unos" type="text" name="vrijeme_od" size="12" value="10.10.1900. 12:00:00" /></td>						
					</tr>
					<tr>
						<td>Vrijeme do:</td>
						<td><input class="tekst_unos" type="text" name="vrijeme_do" size="12" value="10.10.2100. 12:00:00" /></td>						
					</tr>
					<tr>
											
					</tr>
				</tbody>
				
			</form>
			
		</table>		
			
		<div class="grid-container">
			<?php			
				if ($rezultat) {
					while ($red = mysqli_fetch_array($rezultat)) {
					echo "<div class='grid-objekt'>
							<a href='podaci_o_slici.php?id_slike={$red['slika_id']}'>
								<img class='javna_slika' src='{$red['url']}' width='450px' height='288px' />
							</a>
						  </div>
						";
					}
				}		
			?>
		</div>		
		
		<?php
			include_once ('footer.php');
		?>
	
	</body>

</html>