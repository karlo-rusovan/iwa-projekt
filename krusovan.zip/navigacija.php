<?php 
	if (isset($_SESSION["korisnik_id"])) { 
?>	
	<nav>
			<a href='index.php'>Početna</a>
			<a href='galerija_slika.php'>Galerija slika</a>
			<a href='slike_korisnika.php'>Slike korisnika</a>		
	
<?php 
		if ($_SESSION["tip_korisnika"] == 1) {		

?>
			<a href='planine_moderatora.php'>Planine moderatora</a>	
<?php
		} else if ($_SESSION["tip_korisnika"] == 0) {	
?>			
			<a href='korisnici.php'>Korisnici</a> 
			<a href='planine.php'>Planine</a>
<?php
		} 
?>			
			<a href='prijava.php?odjava=1'>Odjava</a>
	</nav>
<?php		
	} else { 
?>

	<nav>
			<a href='index.php'>Početna</a>
			<a href='o_autoru.php'>O autoru</a>
			<a href='galerija_slika.php'>Galerija slika</a>
			<a href='prijava.php'>Prijava</a>
	</nav>

<?php 
	} 
?>
