<?php 
	
	$id_slike = $_GET['id_slike'];
	
	session_start();
	
	include_once ('baza.php');
	$veza = baza_spajanje();	
	
	$upit = "SELECT slika.*, planina.naziv as naziv_planine
	FROM slika
	INNER JOIN planina
	ON slika.planina_id = planina.planina_id	
	WHERE slika_id = {$id_slike} ";		
	$rezultat = izvrsiUpit($veza,$upit);	
	
	$upit_blokiran = "SELECT * FROM korisnik
	WHERE korisnik_id = {$_SESSION['korisnik_id']}";		
	$rezultat_blokiran = izvrsiUpit($veza,$upit_blokiran);
	$red_blokiran = mysqli_fetch_array($rezultat_blokiran);
		
	if (isset($_GET['azuriraj'])) {	
		
		$planina = $_GET['planina'];
		$naziv = $_GET['naziv'];
		$opis = $_GET['opis'];
		$status = $_GET['status'];
		$datum = date("Y-m-d H:i:s", strtotime($_GET['datum']));
		$id_slike = $_GET['id_slike'];
				
		
		if(empty($planina) || empty($naziv) || empty($opis) || empty($datum)) {
			$podaci_nisu_uneseni = " ";
		} else {		
			$upit_azuriraj = "UPDATE slika
			SET planina_id = '{$planina}', naziv = '{$naziv}', opis = '{$opis}', datum_vrijeme_slikanja = '{$datum}',  status = '{$status}' 
			WHERE slika_id = '{$id_slike}'";	
			izvrsiUpit($veza,$upit_azuriraj);		
			
			header("Location: azuriranje_slike.php?id_slike={$id_slike}&azuriranje=da");	
							
			}				
		}
		
	

?>

<!DOCTYPE html>
<html>

	<head>
	
		<title>Ažuriranje slike</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
		
	</head>
	
	<body>	
		
		<header> 		
			<h1>Ažuriranje podataka o slici</h1>				
		</header>
	
		<?php
			include_once ('navigacija.php');	
			
			$red = mysqli_fetch_array($rezultat);
				
			$datum = date("d.m.Y H:i:s", strtotime($red['datum_vrijeme_slikanja']));
		?>					
		
		<table id="tablica_azuriranje">
			
						
			<img style="float:left" src='<?php echo $red['url'] ?>' width='450px' height='288px' /> 
							
			
			<tr>
				<form name="filtriranje_slika" action="<?php echo $_SERVER['PHP_SELF']?>" method='GET'>			
				<td><label for="planina">Planina:</label></td>
				<td><select name="planina" class="tekst_unos" id="dropdown_planine">
					
					<?php
						
						$upit_planine = "SELECT * FROM planina";							
						$rezultat_planine = izvrsiUpit($veza,$upit_planine);						
						
						if ($rezultat_planine) {						
							
														
							while($red_planine = mysqli_fetch_array($rezultat_planine)) {
								
								$planina_id = $red_planine['planina_id'];
								$planina_naziv = $red_planine['naziv'];							
								
								echo "<option value='{$planina_id}'";?>

                                <?php 
                                    if($red['planina_id'] == $planina_id) {
                                        echo "selected";
                                    } 
                                ?> <?php 

                                echo">{$planina_naziv}</option>";
																
							}				
						}
						
					?>						
				</select></td>
			</tr>
			<tr>
				<td><label for="naziv">Naziv:</label></td>
				<td><input type="text" name="naziv" class="tekst_unos" size="23" value="<?php echo $red['naziv'] ?>" /></td>
			</tr>
			<tr>
				<td><label for="naziv">Opis:</label></td>
				<td><textarea name="opis" cols="25" class="tekst_unos"><?php echo $red['opis'] ?></textarea></td>
			</tr>
			<tr>
				<td><label for="datum">Datum slike:</label></td>
				<td><input type="text" name="datum" class="tekst_unos" size="23" value="<?php echo $datum ?>" /></td>
			</tr>
			<tr>				
				<td><label for="status">Javna:</label></td>
				<td><input type="radio" name="status" value="1"
				<?php
					if ($red_blokiran['blokiran'] == 1) {
						echo "disabled";
					} else if($red['status'] == 1) { 
					echo "checked"; 
					}
				?> 
				/></td>
			</tr>
			<tr>
				<td><label for="status">Privatna:</label></td>
				<td><input type="radio" name="status" value="0" <?php if($red['status'] == 0) { echo "checked"; }?> /></td>
			</tr>
			<tr>
			
				<td><input type="submit" name="azuriraj" value="Ažuriraj" class="gumb" /></td>				
				<td><input type="text" name="id_slike" class="tekst_unos" value="<?php echo $id_slike ?>" style="display:none;" /></td>
			</tr>					
				</form>			
		</table>
		
		<?php
			if(isset($_GET['azuriranje'])){
				Echo "<div class='alert' id='tablica_azuriranje'>Uspješno ažurirano</div>";
				} else if (isset($podaci_nisu_uneseni)) {
					Echo "<div class='alert' id='tablica_azuriranje'>Potrebno je popuniti sve podatke</div>";
				}
		?>
		
		<?php
			include_once ('footer.php');			
			zatvoriVezuNaBazu($veza);
		?>
		
	</body>
	
</html>

