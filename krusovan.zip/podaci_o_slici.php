<?php 

	$id_slike = $_GET['id_slike'];
	
	session_start();

	include_once ('baza.php');
	$veza = baza_spajanje();		
	
	$upit = "SELECT slika.*, planina.naziv as naziv_planine, planina.opis as planina_opis,
	korisnik.*  FROM slika
	INNER JOIN planina
	ON slika.planina_id = planina.planina_id
	INNER JOIN korisnik
	ON slika.korisnik_id = korisnik.korisnik_id
	WHERE slika_id = {$id_slike} ";		
	$rezultat = izvrsiUpit($veza,$upit);	

	zatvoriVezuNaBazu($veza);

?>

<!DOCTYPE html>
<html>

	<head>
	
		<title>Podaci</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
		
	</head>
	
	<body>	
		
		<header> 		
			<h1>Podaci o slici</h1>				
		</header>
	
		<?php
			include_once ('navigacija.php');
			
			$red = mysqli_fetch_array($rezultat);
			$url = $red['url'];
			$naziv_planine = $red['naziv_planine'];
			$korisnicko_ime = $red['korisnicko_ime'];
			$ime = $red['ime'];
			$prezime = $red['prezime'];
			$korisnik_id = $red['korisnik_id'];
			$naziv = $red['naziv'];
			$opis = $red['opis'];
			$datum_vrijeme_slikanja = $red['datum_vrijeme_slikanja'];
			$planina_opis = $red['planina_opis'];
			
			echo "			
			<table>		
			<tr>			
				<td>
					<img src='{$url}' width='450px' height='288px' />
				</td>
				
				<td>
					<ul>
						<li>Planina:
							<a href='galerija_slika.php?naziv_planine={$naziv_planine}'>
								{$naziv_planine}
							</a>
						</li>		
						<li>Korisnik:
								{$ime}
							<a href='galerija_slika.php?korisnik_id={$korisnik_id}'>
								 {$prezime}
							</a>
						</li>	
						<li>Naziv slike: {$naziv}</li>	
						<li>Opis: {$opis}</li>	
						<li>Vrijeme slikanja: {$datum_vrijeme_slikanja}</li>
						<li><div style='width:50%'>Opis planine: {$planina_opis}</div></li>
					</ul>	
				</td>
			</tr>				
		</table>
		";
			
		?>	
		
		<?php
			include_once ('footer.php');
		?>
		
	</body>
	
</html>

