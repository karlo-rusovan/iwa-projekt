<?php 
	
	session_start();

	include_once ('baza.php');
	$veza = baza_spajanje();	
	
	if (!isset($_SESSION['tip_korisnika']) || $_SESSION["tip_korisnika"] != 0) {
		 header('Location: prijava.php');
	}	
		
	$upit = "SELECT * FROM korisnik WHERE tip_korisnika_id = '1'";
    $rezultat = izvrsiUpit($veza, $upit);
	
	if (isset($_POST['unesi_planinu'])) {	
		
		$naziv = $_POST['naziv'];
		$opis = $_POST['opis'];
		$lokacija = $_POST['lokacija'];
		$geografska_sirina = $_POST['geografska_sirina'];
		$geografska_duzina = $_POST['geografska_duzina'];
			
		
		if(empty($naziv) || empty($opis) || empty($lokacija) || empty($geografska_sirina) || empty($geografska_duzina) || empty($_POST['moderator'])) {
			$podaci_nisu_uneseni = " ";
		} else {
			
			$upit_unesi = "INSERT INTO planina
			(`naziv`, `opis`, `lokacija`, `geografska_sirina`, `geografska_duzina`) 
			VALUES ('{$naziv}','{$opis}','{$lokacija}','{$geografska_sirina}','{$geografska_duzina}')";	
			izvrsiUpit($veza,$upit_unesi);					
			
			$planina_id = mysqli_insert_id($veza);
			
			foreach ($_POST['moderator'] as $index ) {
				echo $index;
				$upit_moderator_unesi = "INSERT INTO `moderator`(`korisnik_id`, `planina_id`) VALUES ('{$index}','{$planina_id}')";
				izvrsiUpit($veza,$upit_moderator_unesi);
			}				
			
			header("Location: planine.php");									
			}				
		}
	

?>

<!DOCTYPE html>
<html>

	<head>
	
		<title>Planine - unos</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
		
	</head>
	
	<body>	
		
		<header> 		
			<h1>Unos planine</h1>				
		</header>
	
		<?php
			include_once ('navigacija.php');					
		?>				
		
		<table id="tablica_azuriranje">			
			
			<img style="float:left" src='http://www.discoverdinarides.com/content/big_579b3d9f62a92.jpg' width='450px' height='288px' /> 
			
			<form name="unos_planine" method="POST" action="<?php echo $_SERVER['PHP_SELF']?>">
				<tr>
					<td><label for="naziv">Naziv</label></td>
					<td><input type="text" class="tekst_unos" name="naziv"/></td>
				</tr>				
				<tr>
					<td><label for="lokacija">Lokacija</label></td>
					<td><input type="text" class="tekst_unos" name="lokacija" /></td>
				</tr>
				<tr>
					<td><label for="geografska_sirina">Geografska širina</label></td>
					<td><input type="text" class="tekst_unos" name="geografska_sirina" /></td>
				</tr>
				<tr>
					<td><label for="geografska_duzina">Geografska dužina</label></td>
					<td><input type="text" class="tekst_unos" name="geografska_duzina"/></td>
				</tr>
				<tr>
					<td><label for="moderator">Moderatori</label></td>	
					<td><select name='moderator[]' size="2"  id="mod_dropdown" multiple>
					<?php 
						if ($rezultat) {
														
							while ($red = mysqli_fetch_array($rezultat)) {
								
								$korisnicko_ime = $red['korisnicko_ime'];
								$korisnik_id = $red['korisnik_id'];														
					 ?>	
								
								<option value='<?=$korisnik_id?>'>
									<?=$korisnicko_ime?>
								</option>	
					<?php	
								
							}
						}
					?>
					</select></td>
				</tr>
				<tr>
					<td><label for="opis">Opis</label></td>
					<td><textarea name="opis" cols="50" rows="6" class="tekst_unos"></textarea></td>
				</tr>
				<tr>
					<td><input type="submit" class="gumb" name="unesi_planinu" value="Unesi" /></td>												
				</tr>
			</form>
		</table>
		
		<?php
			if (isset($podaci_nisu_uneseni)) {
					Echo "<div class='alert' id='tablica_azuriranje'>Potrebno je popuniti sve podatke</div>";
				}
		?>
		
		<?php
			include_once ('footer.php');
			
				zatvoriVezuNaBazu($veza);

		?>
		
	</body>
	
</html>

