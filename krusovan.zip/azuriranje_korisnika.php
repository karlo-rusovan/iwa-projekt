<?php 

	session_start();

	include_once ('baza.php');
	$veza = baza_spajanje();	
	
	if (!isset($_SESSION['tip_korisnika']) || $_SESSION["tip_korisnika"] != 0) {
		 header('Location: prijava.php');
	}	
	
	$korisnik_id = $_GET['korisnik_id'];
	$upit = "SELECT * from korisnik WHERE korisnik_id = '{$korisnik_id}'";
	$rezultat = izvrsiUpit($veza,$upit);
	$red = mysqli_fetch_array($rezultat);

	if (isset($_GET['azuriraj_korisnika'])) {	
		
		$tip_korisnika_id = $_GET['tip_korisnika_id'];
		$korisnicko_ime = $_GET['korisnicko_ime'];
		$ime = $_GET['ime'];
		$prezime = $_GET['prezime'];
		$email = $_GET['email'];
		$blokiran = $_GET['blokiran'];
		$slika = $_GET['slika'];
				
		
		if(empty($tip_korisnika_id) || empty($korisnicko_ime) || empty($ime) || empty($prezime) || empty($email)) {
			$podaci_nisu_uneseni = " ";
		} else {
			
			$upit_azuriraj = "UPDATE korisnik
			SET tip_korisnika_id = '{$tip_korisnika_id}', korisnicko_ime = '{$korisnicko_ime}', ime = '{$ime}', prezime = '{$prezime}',
			email = '{$email}', blokiran = '{$blokiran}', slika = '{$slika}'
			WHERE korisnik_id = '{$korisnik_id}'";	
			izvrsiUpit($veza,$upit_azuriraj);			

			header("Location: azuriranje_korisnika.php?korisnik_id={$korisnik_id}&azuriranje_uspjesno=da");									
			}				
		}

	zatvoriVezuNaBazu($veza);

	

?>

<!DOCTYPE html>
<html>

	<head>
	
		<title>Korisnici - ažuriranje</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
		
	</head>
	
	<body>	
		
		<header> 		
			<h1>Ažuriranje podataka korisnika</h1>				
		</header>

		<?php
			include_once ('navigacija.php');					
		?>				

		<table id="tablica_azuriranje">			
			
			<img style="float:left" src='https://live.staticflickr.com/4511/36844950564_70b897f770_z.jpg' width='450px' height='288px' /> 
			
			<form name="azuriranje_korisnika" method="GET" action="<?php echo $_SERVER['PHP_SELF']?>">
				<tr>
					<td><label for="tip_korisnika_id">Tip korisnika</label></td>
					<td><select name="tip_korisnika_id" class="tekst_unos" id="dropdown_tip"> 
						<option value='0'
						<?php
							if($red['tip_korisnika_id'] == 0) {
								echo "selected";
							}								
						?>>Administrator
						</option>
						<option value='1'
						<?php
							if($red['tip_korisnika_id'] == 1) {
								echo "selected";
							}	
						?>>Moderator
						</option>
						<option value='2'
						<?php
							if($red['tip_korisnika_id'] == 2) {
								echo "selected";
							} 								
						?>>Korisnik
						</option>
					</td>
				</tr>
				<tr>
					<td><label for="korisnicko_ime">Korisničko ime</label></td>
					<td><input type="text" class="tekst_unos" name="korisnicko_ime" value="<?= $red['korisnicko_ime'] ?>" /></td>
				</tr>
				<tr>
					<td><label for="ime">Ime</label></td>
					<td><input type="text" class="tekst_unos" name="ime" value="<?= $red['ime'] ?>" /></td>
				</tr>
				<tr>
					<td><label for="prezime">Prezime</label></td>
					<td><input type="text" class="tekst_unos" name="prezime" value="<?= $red['prezime'] ?>" /></td>
				</tr>
				<tr>
					<td><label for="email">Email</label></td>
					<td><input type="text" class="tekst_unos" name="email" value="<?= $red['email'] ?>" /></td>
				</tr>
				<tr>
					<td><label for="blokiran">Blokiran</label></td>
					<td><select name="blokiran" class="tekst_unos" id="dropdown_tip"> 
						<option value='0'
						<?php
							if($red['blokiran'] == 0) {
								echo "selected";
							} else {
								echo "disabled";
							}			
						?>>Nije blokiran
						</option>
						<option value='1'
						<?php
							if($red['blokiran'] == 1) {
								echo "selected";
							} else {
								echo "disabled";
							}
						?>>Blokiran						
					</td>
				</tr>
				<tr>
					<td><label for="slika">Slika</label></td>
					<td><input type="text" class="tekst_unos" name="slika" value="<?= $red['slika'] ?>" /></td>
				</tr>
				<tr>					
					<td><input type="submit" class="gumb" name="azuriraj_korisnika" value="Ažuriraj" /></td>					
					<td><input type="text" name="korisnik_id" class="tekst_unos" value="<?php echo $korisnik_id ?>" style="display:none;" /></td>
				</tr>
			</form>
		</table>
		
		<?php
			if(isset($_GET['azuriranje_uspjesno'])){
				Echo "<div class='alert' id='tablica_azuriranje'>Uspješno ažurirano</div>";
				} else if (isset($podaci_nisu_uneseni)) {
					Echo "<div class='alert' id='tablica_azuriranje'>Potrebno je popuniti sve podatke</div>";
				}
		?>

		<?php
			include_once ('footer.php');
		?>
		
	</body>
	
</html>

