<?php 		

	include_once ('baza.php');
	$veza = baza_spajanje();	
	
	session_start();	

	if (isset($_GET["odjava"])) {
		unset($_SESSION["korisnik_id"]) ;				
		unset($_SESSION["ime"]) ;		
		unset($_SESSION["prezime"])  ;
		unset($_SESSION["tip_korisnika"]);	
		session_destroy();		
	}		
	
	$neuspjesna_prijava = 0;
	
	if (isset($_POST['korisnicko_ime']) && isset($_POST['lozinka'])) {
		
		$korisnicko_ime = $_POST['korisnicko_ime'];
		$lozinka = $_POST['lozinka'];
		
		$upit = "SELECT * FROM korisnik WHERE korisnicko_ime='{$korisnicko_ime}' AND lozinka='{$lozinka}'";			
		$rezultat = izvrsiUpit($veza,$upit);
		
		$red = mysqli_fetch_array($rezultat);
		
		if ($red) {
			header('Location: index.php');
			
			$_SESSION["korisnik_id"] = $red["korisnik_id"] ;			
			$_SESSION["ime"] = $red["ime"] ;
			$_SESSION["prezime"] = $red["prezime"] ;			
			$_SESSION["tip_korisnika"] = $red["tip_korisnika_id"];				
				
		} else {
			$neuspjesna_prijava = 1;
		}
		
	}
	
	zatvoriVezuNaBazu($veza);

?>

<!DOCTYPE html>
<html>

	<head>
	
		<title>Prijava</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
		
	</head>
	
	<body>	
		
		<header> 		
			<h1>Prijava</h1>				
		</header>	
		
		<?php
			include_once ('navigacija.php');
		?>	
		
			<form id="prijava" name="prijava" method="POST" action="<?php echo $_SERVER['PHP_SELF']?>" id="filtriranje_slika" >
				
					<div><input class="prijava_unos" type="text" name="korisnicko_ime" size="30" placeholder="korisničko ime" /></div>				
				
					<div><input class="prijava_unos" type="password" name="lozinka" size="30" placeholder="lozinka" /></div>				
				
					<div><input class="gumb" id="prijava_gumb" type="submit" name="prijava" size="12" value="Prijava" /></div>
					
					<div>
					<?php
						if ($neuspjesna_prijava === 1) {
							echo "Prijava neuspješna";
						} else if (isset($_GET["odjava"])) {
							echo "Odjava uspješna";
						}
					?>
					</div>
								
			</form>		
	
		<?php
			include_once ('footer.php');
		?>
		
	</body>
	
</html>

