<!DOCTYPE html>
<?php
	
	session_start();	

	include_once ('baza.php');
	$veza = baza_spajanje();	

	zatvoriVezuNaBazu($veza);	
?>


<html>
	
	<head>
		
		<title>Početna</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
	
	</head>	
	
	<body>		
		
		<header> 		
			<h1>Početna stranica</h1>				
		</header>
	
		<?php
			include_once ('navigacija.php');
		?>	
		
		
		<a href="galerija_slika.php"><img src="slike/dinara.png" width="100%" /></a>
		
		<?php
			include_once ('footer.php');
		?>
	
	</body>

</html>