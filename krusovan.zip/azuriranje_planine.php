<?php 
	session_start();
	
	include_once ('baza.php');
	$veza = baza_spajanje();
	
	if (!isset($_SESSION['tip_korisnika']) || $_SESSION["tip_korisnika"] != 0) {
		 header('Location: prijava.php');
	}	
	if (isset($_GET['planina_id']) && isset($_GET['planina_url'])) {
		$planina_id = $_GET['planina_id'];
		$planina_url = $_GET['planina_url'];
		
	} else {
		$planina_id = $_POST['planina_id'];
		$planina_url = $_POST['planina_url'];	
			
	}
	
	
	$upit = "SELECT * from planina	
	WHERE planina.planina_id = '{$planina_id}'";
	$rezultat = izvrsiUpit($veza,$upit);
	$red = mysqli_fetch_array($rezultat);
	
	$upit_moderatori = "SELECT DISTINCT moderator.korisnik_id as moderator_korisnik_id, korisnik.* FROM moderator
	RIGHT JOIN korisnik ON moderator.korisnik_id = korisnik.korisnik_id
	WHERE korisnik.tip_korisnika_id = '1'";
    $rezultat_moderatori = izvrsiUpit($veza, $upit_moderatori);
	
	if (isset($_POST['azuriraj_planinu'])) {	
		
		$naziv = $_POST['naziv'];
		$opis = $_POST['opis'];
		$lokacija = $_POST['lokacija'];
		$geografska_sirina = $_POST['geografska_sirina'];
		$geografska_duzina = $_POST['geografska_duzina'];
			
		
		if(empty($naziv) || empty($opis) || empty($lokacija) || empty($geografska_sirina) || empty($geografska_duzina) || empty($_POST['moderator'])) {
			$podaci_nisu_uneseni = " ";
		} else {
			
			$upit_azuriraj = "UPDATE planina
			SET naziv = '{$naziv}', opis = '{$opis}', lokacija = '{$lokacija}', geografska_sirina = '{$geografska_sirina}',
			geografska_duzina = '{$geografska_duzina}'
			WHERE planina_id = '{$planina_id}'";	
			izvrsiUpit($veza,$upit_azuriraj);	
			
			$upit_moderator_brisi = "DELETE FROM moderator WHERE  planina_id = '{$planina_id}'";
			izvrsiUpit($veza,$upit_moderator_brisi);		
			
			foreach ($_POST['moderator'] as $index ) {
				echo $index;
				$upit_moderator_azuriraj = "INSERT INTO `moderator`(`korisnik_id`, `planina_id`) VALUES ('{$index}','{$planina_id}')";
				izvrsiUpit($veza,$upit_moderator_azuriraj);
			}				
			
			header("Location: azuriranje_planine.php?planina_id={$planina_id}&azuriranje_uspjesno=da&planina_url={$planina_url}");									
			}				
		}
	

?>

<!DOCTYPE html>
<html>

	<head>
	
		<title>Planine - ažuriranje</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
		
	</head>
	
	<body>	
		
		<header> 		
			<h1>Ažuriranje podataka planine</h1>				
		</header>
	
		<?php
			include_once ('navigacija.php');					
		?>				
	
		<table id="tablica_azuriranje">			
			
			<img style="float:left" src='<?= $planina_url ?>' width='450px' height='288px' /> 
			
			<form name="azuriranje_planine" method="POST" action="<?php echo $_SERVER['PHP_SELF']?>">
				<tr>
					<td><label for="naziv">Naziv</label></td>
					<td><input type="text" class="tekst_unos" name="naziv" value="<?= $red['naziv'] ?>" /></td>
				</tr>				
				<tr>
					<td><label for="lokacija">Lokacija</label></td>
					<td><input type="text" class="tekst_unos" name="lokacija" value="<?= $red['lokacija'] ?>" /></td>
				</tr>
				<tr>
					<td><label for="geografska_sirina">Geografska širina</label></td>
					<td><input type="text" class="tekst_unos" name="geografska_sirina" value="<?= $red['geografska_sirina'] ?>" /></td>
				</tr>
				<tr>
					<td><label for="geografska_duzina">Geografska dužina</label></td>
					<td><input type="text" class="tekst_unos" name="geografska_duzina" value="<?= $red['geografska_duzina'] ?>" /></td>
				</tr>
				<tr>
					<td><label for="moderator">Moderatori</label></td>	
					<td><select name='moderator[]' size="2"  id="mod_dropdown" multiple>
					<?php 
						if ($rezultat_moderatori) {
														
							while ($red_moderatori = mysqli_fetch_array($rezultat_moderatori)) {
								
								$korisnicko_ime = $red_moderatori['korisnicko_ime'];
								$korisnik_id = $red_moderatori['korisnik_id'];	
								
                                $upit_planine_korisnika = "SELECT * FROM moderator
								WHERE korisnik_id = '{$korisnik_id}'";
                                $rezultat_planine_korisnika = izvrsiUpit($veza, $upit_planine_korisnika);

                                $planine_korisnika = array();
                                $i = 0;
								
                                while ($red_planine_korisnika = mysqli_fetch_array($rezultat_planine_korisnika)) {
                                    $planine_korisnika[$i] = $red_planine_korisnika['planina_id'];									
									$i++;		
								}							
								
					?>	
								
								<option value='<?=$korisnik_id?>' <?php
									if(in_array($red['planina_id'], $planine_korisnika)) {
										echo "selected";
									}
								?>>
									<?=$korisnicko_ime?>
								</option> ";	
					<?php	
								
							}
						}
					?>
					</select></td>
				</tr>
				<tr>
					<td><label for="opis">Opis</label></td>
					<td><textarea name="opis" cols="50" rows="6" class="tekst_unos"><?php echo $red['opis'] ?></textarea></td>
				</tr>
				<tr>
					<td><input type="submit" class="gumb" name="azuriraj_planinu" value="Ažuriraj" /></td>	
					<td><input type="text" name="planina_id" class="tekst_unos" value="<?php echo $planina_id ?>" style="display:none" /></td>
					<td><input type="text" name="planina_url" class="tekst_unos" value="<?php echo $planina_url ?>" style="display:none" /></td>
							
					
				</tr>
			</form>
		</table>
		
		<?php
			if(isset($_GET['azuriranje_uspjesno'])){
				Echo "<div class='alert' id='tablica_azuriranje'>Uspješno ažurirano</div>";
				} else if (isset($podaci_nisu_uneseni)) {
					Echo "<div class='alert' id='tablica_azuriranje'>Potrebno je popuniti sve podatke</div>";
				}
		?>
		
		<?php
			include_once ('footer.php');
			
				zatvoriVezuNaBazu($veza);

		?>
		
	</body>
	
</html>

