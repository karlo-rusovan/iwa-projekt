<?php 
	session_start();

	include_once ('baza.php');
	$veza = baza_spajanje();	

	if (!isset($_SESSION['tip_korisnika']) || $_SESSION["tip_korisnika"] != 0) {
		 header('Location: prijava.php');
	}
	
	$upit = "SELECT * from korisnik	
	ORDER BY korisnik.prezime";	
	$rezultat = izvrsiUpit($veza, $upit);	

?>

<!DOCTYPE html>
<html>

	<head>
	
		<title>Korisnici</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
		
	</head>
	
	<body>	
		
		<header> 		
			<h1>Popis korisnika</h1>				
		</header>

		<?php
			include_once ('navigacija.php');					
		?>	
		
		<a href="korisnici.php?blokirani=0"><input type="button" name="unos" class="gumb" value="Svi korisnici" /></a>
		<a href="korisnici.php?blokirani=1"><input type="button" name="unos" class="gumb" value="Blokirani korisnici" /></a>		
		<a href="statistika.php"><input type="button" name="unos" class="gumb" value="Statistika slika po korisniku" /></a>
		<a href="unos_korisnika.php"><input type="button" name="unos" class="gumb" value="Unos novog korisnika" /></a>

		<table id="popis_korisnika_tablica">
			<thead>
				<tr>
					<th class='popis_korisnika'>Tip korisnika</th>
					<th class='popis_korisnika'>Korisničko ime</th>
					<th class='popis_korisnika'>Ime</th>
					<th class='popis_korisnika'>Prezime</th>
					<th class='popis_korisnika'>Email</th>
					<th class='popis_korisnika'>Broj javnih slika</th>
					<th class='popis_korisnika'>Broj privatnih slika</th>
					
				</tr>
			</thead>			
			<tbody>
			<?php
				if ($rezultat) {
					while ($red = mysqli_fetch_array($rezultat)) { 
					
					$korisnik_id = $red['korisnik_id'];
					$tip_korisnika_id = $red['tip_korisnika_id'];
					$korisnicko_ime = $red['korisnicko_ime'];
					$ime = $red['ime'];
					$prezime = $red['prezime'];
					$email = $red['email'];
					$blokiran = $red['blokiran'];
					$slika = $red['slika'];
					
					echo "<tr>							
					<td style='text-align:center; class='popis_korisnika''>{$tip_korisnika_id}</td>
					<td class='popis_korisnika'><a href='galerija_slika.php?korisnik_id={$korisnik_id}'>{$korisnicko_ime}</a></td>
					<td class='popis_korisnika'>{$ime}</td>
					<td class='popis_korisnika'>{$prezime}</td>
					<td class='popis_korisnika'>{$email}</td>" ?>
							
			<?php
							
					$upit_javne = "SELECT COUNT(status) as broj_javnih FROM slika					
					WHERE status = '1' AND slika.korisnik_id = '{$korisnik_id}'";
					$rezultat_javne = izvrsiUpit($veza, $upit_javne);
					$red_javne = mysqli_fetch_array($rezultat_javne);
					
					echo "<td style='text-align:center;' class='popis_korisnika'>{$red_javne['broj_javnih']}</td>";
								
					$upit_privatne = "SELECT COUNT(status) as broj_privatnih FROM slika					
					WHERE status = '0' AND slika.korisnik_id = '{$korisnik_id}'";
					$rezultat_privatne = izvrsiUpit($veza, $upit_privatne);
					$red_privatne = mysqli_fetch_array($rezultat_privatne);
					
					echo "<td style='text-align:center;' class='popis_korisnika'>{$red_privatne['broj_privatnih']}</td>";

			?>
			<?php echo "</tr>";				
					}
				}
			?>
			</tbody>
		</table>
	
		<?php
			include_once ('footer.php');
			zatvoriVezuNaBazu($veza);
		?>
		
	</body>
	
</html>

