<?php 		
	session_start();
	
	if (!isset($_SESSION["korisnik_id"])) {
	   header('Location: prijava.php');
	   }	

	include_once ('baza.php');
	$veza = baza_spajanje();	
	
	$korisnik_id = $_SESSION['korisnik_id'];	
		
	if (isset($_GET['select']) && isset($_GET['filter'])) {		
		
		$status_slike = $_GET['select'];
		
		if ($status_slike === "sve") {
			
			$upit = "SELECT * FROM slika
			WHERE korisnik_id = {$korisnik_id} ";		
			$rezultat = izvrsiUpit($veza,$upit);
		} else {
			
			$upit = "SELECT * FROM slika
			WHERE korisnik_id = {$korisnik_id} AND status = {$status_slike} ";		
			$rezultat = izvrsiUpit($veza,$upit);
		}
		
	} else {	
	
		$upit = "SELECT * FROM slika
		WHERE korisnik_id = {$korisnik_id} ";		
		$rezultat = izvrsiUpit($veza,$upit);		
	}
	
	$upit_blokiran = "SELECT * FROM korisnik
	WHERE korisnik_id = {$korisnik_id}";		
	$rezultat_blokiran = izvrsiUpit($veza,$upit_blokiran);
	$red_blokiran = mysqli_fetch_array($rezultat_blokiran);
	
	zatvoriVezuNaBazu($veza);

?>

<!DOCTYPE html>
<html>

	<head>
	
		<title>Slike korisnika</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<meta content="width=device-width, initial-scale=1" name="viewport" />
		<link rel="stylesheet" href="dizajn.css" />
		
	</head>
	
	<body>	
		
		<header> 		
			<h1>Slike korisnika</h1>				
		</header>	
	
		<?php
			include_once ('navigacija.php');
					
		?>	
		
		<form name="slike_korisnika_filter" action="<?php echo $_SERVER['PHP_SELF']?>" method="GET">
			<table>			
				<tr>
					<td class="korisnik_filter">
						<?php
							if($red_blokiran['blokiran'] == 0) {
								echo "Status: nije blokiran";								
							} else {
								echo "Status: blokiran je";
							}
						?>
					</td>
					<td class="korisnik_filter">
						<select class="tekst_unos" name="select">
							<option value="sve" selected>Sve slike</option>
							<option value="0">Samo privatne slike</option>
							<option value="1">Samo javne slike</option>
						</select>
					</td>
					<td class="korisnik_filter"><input class="gumb" type="submit" name="filter" value="Filtriraj" /></td>
					<td class="korisnik_filter">
						<a href="dodavanje_slike.php"><input class="gumb" type="button" name="dodaj_sliku" value="Dodaj sliku" /></a>
					</td>
				</tr>			
			</table>
		</form>				
			
		<div class="grid-container">
			<?php			
				if ($rezultat) {
					while ($red = mysqli_fetch_array($rezultat)) {
					echo "<div class='grid-objekt'>
							<a href='azuriranje_slike.php?id_slike={$red['slika_id']}'>
								<img class='javna_slika' src='{$red['url']}' width='450px' height='288px' />
							</a>
						  </div>
						";
					}
				}		
			?>
		</div>		
	
		<?php
			include_once ('footer.php');
		?>
		
	</body>
	
</html>

