<?php 
	echo "<footer>
				<a href='mailto:krusovan@foi.hr'>Kontakt: krusovan@foi.hr - Hrvatske planine</a>				
		  </footer>";
?>