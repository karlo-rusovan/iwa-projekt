<!DOCTYPE html>

<?php
	session_start();
	
	if (!isset($_SESSION['tip_korisnika']) || $_SESSION["tip_korisnika"] != 1)  {
		 header('Location: prijava.php');
	}

	include_once ('baza.php');
	$veza = baza_spajanje();	
	
	$id_moderatora = $_SESSION["korisnik_id"];
	$upit_naziv = " SELECT moderator.planina_id, planina.naziv FROM moderator
	INNER JOIN planina ON planina.planina_id = moderator.planina_id	
	WHERE moderator.korisnik_id = {$id_moderatora} ";		
	$rezultat_naziv = izvrsiUpit($veza,$upit_naziv);

	$upit_slika = " SELECT slika.url FROM slika
	INNER JOIN planina ON planina.planina_id = slika.planina_id	
	INNER JOIN moderator on planina.planina_id = moderator.planina_id
	WHERE moderator.korisnik_id = {$id_moderatora} ";		
	$rezultat_slika = izvrsiUpit($veza,$upit_slika);

	zatvoriVezuNaBazu($veza);

?>	


<html>
	
	<head>
		
		<title>Planine moderatora</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
	
	</head>
	
	<body>		
		
		<header> 		
			<h1>Planine za koje ste zaduženi</h1>				
		</header>
	
		<?php
			include_once ('navigacija.php');
		?>	
		
		<?php
			if ($rezultat_naziv && $rezultat_slika) {
				echo "<table id='moderator_planine_tablica'>";				
				while ($red = mysqli_fetch_array($rezultat_naziv)) {
					$naziv = $red['naziv'];
					$planina = $red['planina_id'];
					$red_slika = mysqli_fetch_array($rezultat_slika);
					$url = $red_slika['url'];			
					
					echo "					
							<tr>
								<td class='moderator_planina'><a href='planina.php?planina_id={$planina}'>{$naziv}</a></td>				
								<td class='moderator_slika'><a href='planina.php?planina_id={$planina}'><img src='{$url}' height='350px' width='600px'/></a></td>
							</tr>					
					";			
				}
				echo "</table>";
			}
		?>
	
		<?php
			include_once ('footer.php');
		?>
	
	</body>

</html>