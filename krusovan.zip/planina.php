<!DOCTYPE html>
<?php
	
	session_start();
	
	if (!isset($_SESSION['tip_korisnika']) || $_SESSION['tip_korisnika'] == 2 )  {
		 header('Location: prijava.php');
	}
	
	$planina_id = $_GET["planina_id"];

	include_once ('baza.php');
	$veza = baza_spajanje();	
	
	$upit = "
	SELECT slika.url, korisnik.ime, korisnik.korisnik_id, korisnik.prezime, korisnik.blokiran FROM slika
	INNER JOIN korisnik ON korisnik.korisnik_id = slika.korisnik_id
	WHERE slika.planina_id = {$planina_id} AND slika.status = '1' ";		
	$rezultat = izvrsiUpit($veza,$upit);	

	$upit_planina = "SELECT naziv FROM planina WHERE planina_id = '{$planina_id}'";
	$rezultat_planina = izvrsiUpit($veza,$upit_planina);
	$red_planina = mysqli_fetch_array($rezultat_planina);

	if (isset($_GET['blokiraj'])) {

		$korisnik = $_GET['korisnik_blokiraj'];		
		$upit_blokiraj = "UPDATE `korisnik` SET `blokiran`='1' WHERE korisnik_id = '{$korisnik}'";
		$rezultat_blokiraj = izvrsiUpit($veza,$upit_blokiraj);
	
		$upit_private = "UPDATE `slika` SET `status`='0' WHERE korisnik_id = '{$korisnik}'";
		$rezultat_private = izvrsiUpit($veza,$upit_private);

		header("Location: planina.php?planina_id={$planina_id}");
	}

	zatvoriVezuNaBazu($veza);

?>	


<html>
	
	<head>
		
		<title>Planina</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
	
	</head>
	
	<body>		
		
		<header> 		
			<h1>Planina <?php echo $red_planina['naziv'] ?></h1>				
		</header>

		<?php
			include_once ('navigacija.php');
		?>	
		
		<?php
		if ($rezultat) {
			echo "<table id='moderator_planina_pregled'>";				
				while ($red = mysqli_fetch_array($rezultat)) {
					$url = $red['url'];
					$ime = $red['ime'];
					$prezime = $red['prezime'];
					$blokiran = $red['blokiran'];
					$korisnik_id = $red['korisnik_id'];
					
					
					?>					
							<tr>								
								<td><img src='<?=$url?>' height='300px' width='500px'/></td>
								<td  style='padding-left:60px'>Korisnik:</td>
								<td><?=$ime . " "?><a href='galerija_slika.php?korisnik_id=<?=$korisnik_id?>'><?=$prezime?></a></td>								
								<td style='padding-left:15px'>
									<form name='filtriranje_slika' action='<?=$_SERVER['PHP_SELF']?>' method='GET'>										
										<input type='text' name='planina_id' style='display:none' value='<?=$_GET['planina_id']?>' />
										<input type='text' name='korisnik_blokiraj' style='display:none' value='<?=$korisnik_id?>' />
										<input type='submit' name='blokiraj' class='gumb' value='Blokiraj' <?php 
										if ($blokiran == 1) {
											echo "disabled";
										}
										?>/>
									</form>
								</td>								
							</tr>					
				<?php			
				}
				echo "</table>";
		}
		?>
	
		<?php
			include_once ('footer.php');
		?>
	
	</body>

</html>