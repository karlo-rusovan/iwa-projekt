<?php 

	session_start();

	include_once ('baza.php');
	$veza = baza_spajanje();	

	if (!isset($_SESSION['tip_korisnika']) || $_SESSION["tip_korisnika"] != 0) {
		 header('Location: prijava.php');	}

	if (isset($_POST['unesi_korisnika'])) {	
		
		$tip_korisnika_id = $_POST['tip_korisnika_id'];
		$korisnicko_ime = $_POST['korisnicko_ime'];
		$lozinka = $_POST['lozinka'];
		$ime = $_POST['ime'];
		$prezime = $_POST['prezime'];
		$email = $_POST['email'];
		$blokiran = $_POST['blokiran'];
		$slika = $_POST['slika'];		
			
			
		if(empty($tip_korisnika_id) || empty($korisnicko_ime) || empty($lozinka) || empty($ime) || empty($prezime) || empty($email)) {
			$podaci_nisu_uneseni = " ";			
		} else {
			
			echo "dodano";
			
			$upit_unesi = "INSERT INTO `korisnik`(`tip_korisnika_id`, `korisnicko_ime`, `lozinka`, `ime`,
			`prezime`, `email`, `blokiran`, `slika`) VALUES ('{$tip_korisnika_id}','{$korisnicko_ime}',
			'{$lozinka}','{$ime}','{$prezime}','{$email}','{$blokiran}','{$slika}')";				
			izvrsiUpit($veza,$upit_unesi);			
			
			$id_dodanog_korisnika = mysqli_insert_id($veza); 
		
			header("Location:azuriranje_korisnika.php?korisnik_id={$id_dodanog_korisnika}");	
			
		}			
	}

	zatvoriVezuNaBazu($veza);

?>

<!DOCTYPE html>
<html>

	<head>
	
		<title>Korisnici - unos</title>
		<meta charset="UTF-8" />
		<meta name="author" content="Karlo Rusovan" />
		<link rel="stylesheet" href="dizajn.css" />
		
	</head>
	
	<body>	
		
		<header> 		
			<h1>Unos novog korisnika</h1>				
		</header>
	
		<?php
			include_once ('navigacija.php');					
		?>	
		
		<table id="tablica_azuriranje">			
			
			<img style="float:left" src='http://www.mnovine.hr/wp-content/uploads/2017/12/Zalazak-sunca-Ivan%C5%A1%C4%8Dica-3.jpg' width='450px' height='288px' /> 
			
			<form name="azuriranje_korisnika" method="POST" action="<?php echo $_SERVER['PHP_SELF']?>">
				<tr>
					<td><label for="tip_korisnika_id">Tip korisnika</label></td>
					<td><select name="tip_korisnika_id" class="tekst_unos" id="dropdown_tip"> 
						<option value='0'>Administrator</option>
						<option value='1'>Moderator</option>
						<option value='2' selected>Korisnik</option>
					</td>
				</tr>
				<tr>
					<td><label for="korisnicko_ime">Korisničko ime</label></td>
					<td><input type="text" class="tekst_unos" name="korisnicko_ime" /></td>
				</tr>
				<tr>
					<td><label for="lozinka">Lozinka</label></td>
					<td><input type="text" class="tekst_unos" name="lozinka" /></td>
				</tr>
				<tr>
					<td><label for="ime">Ime</label></td>
					<td><input type="text" class="tekst_unos" name="ime" /></td>
				</tr>
				<tr>
					<td><label for="prezime">Prezime</label></td>
					<td><input type="text" class="tekst_unos" name="prezime" /></td>
				</tr>
				<tr>
					<td><label for="email">Email</label></td>
					<td><input type="text" class="tekst_unos" name="email" /></td>
				</tr>
				<tr>
					<td><label for="blokiran">Blokiran</label></td>
					<td><select name="blokiran" class="tekst_unos" id="dropdown_tip"> 
						<option value='0' selected >Nije blokiran</option>
						<option value='1'>Blokiran</option>						
					</td>
				</tr>
				<tr>
					<td><label for="slika">Slika</label></td>
					<td><input type="text" class="tekst_unos" name="slika"  /></td>
				</tr>
				<tr>					
					<td><input type="submit" class="gumb" name="unesi_korisnika" value="Unesi" /></td>		
				</tr>
			</form>
		</table>
	
		<?php		    
			if (isset($podaci_nisu_uneseni)) {
					Echo "<div class='alert' class='tablica_azuriranje' style='position:relative;left:50px;'>Potrebno je popuniti sve podatke</div>";
			}
		?>		
	
		<?php
			include_once ('footer.php');
		?>
		
	</body>
	
</html>

